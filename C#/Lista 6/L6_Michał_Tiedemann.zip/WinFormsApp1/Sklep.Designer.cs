﻿namespace WinFormsApp1
{
    partial class Sklep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtImie = new TextBox();
            txtNazwisko = new TextBox();
            txtWiek = new TextBox();
            txtAdres = new TextBox();
            listBoxStore = new ListBox();
            buttonZatwierdz = new Button();
            txtUlubionaKsiazka = new TextBox();
            txtKupionaKsiazka = new TextBox();
            txtRokWydania = new TextBox();
            txtPrzeczytaneStrony = new TextBox();
            txtUlubionyAutor = new TextBox();
            txtKoszyk = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            txtKsiazki = new TextBox();
            txtPracownicy = new TextBox();
            txtSklep = new TextBox();
            txtEmail = new TextBox();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            textBox1 = new TextBox();
            dateCzas = new DateTimePicker();
            SuspendLayout();
            // 
            // txtImie
            // 
            txtImie.Location = new Point(216, 59);
            txtImie.Margin = new Padding(3, 4, 3, 4);
            txtImie.Name = "txtImie";
            txtImie.Size = new Size(114, 27);
            txtImie.TabIndex = 0;
            // 
            // txtNazwisko
            // 
            txtNazwisko.Location = new Point(216, 117);
            txtNazwisko.Margin = new Padding(3, 4, 3, 4);
            txtNazwisko.Name = "txtNazwisko";
            txtNazwisko.Size = new Size(114, 27);
            txtNazwisko.TabIndex = 0;
            // 
            // txtWiek
            // 
            txtWiek.Location = new Point(216, 184);
            txtWiek.Margin = new Padding(3, 4, 3, 4);
            txtWiek.Name = "txtWiek";
            txtWiek.Size = new Size(114, 27);
            txtWiek.TabIndex = 0;
            // 
            // txtAdres
            // 
            txtAdres.Location = new Point(216, 253);
            txtAdres.Margin = new Padding(3, 4, 3, 4);
            txtAdres.Name = "txtAdres";
            txtAdres.Size = new Size(114, 27);
            txtAdres.TabIndex = 0;
            // 
            // listBoxStore
            // 
            listBoxStore.FormattingEnabled = true;
            listBoxStore.ItemHeight = 20;
            listBoxStore.Location = new Point(947, 74);
            listBoxStore.Margin = new Padding(3, 4, 3, 4);
            listBoxStore.Name = "listBoxStore";
            listBoxStore.Size = new Size(305, 564);
            listBoxStore.TabIndex = 1;
            // 
            // buttonZatwierdz
            // 
            buttonZatwierdz.Location = new Point(385, 412);
            buttonZatwierdz.Margin = new Padding(3, 4, 3, 4);
            buttonZatwierdz.Name = "buttonZatwierdz";
            buttonZatwierdz.Size = new Size(185, 80);
            buttonZatwierdz.TabIndex = 2;
            buttonZatwierdz.Text = "Zatwierdź";
            buttonZatwierdz.UseVisualStyleBackColor = true;
            buttonZatwierdz.Click += buttonZatwierdz_Click;
            // 
            // txtUlubionaKsiazka
            // 
            txtUlubionaKsiazka.Location = new Point(747, 122);
            txtUlubionaKsiazka.Margin = new Padding(3, 4, 3, 4);
            txtUlubionaKsiazka.Name = "txtUlubionaKsiazka";
            txtUlubionaKsiazka.Size = new Size(114, 27);
            txtUlubionaKsiazka.TabIndex = 0;
            // 
            // txtKupionaKsiazka
            // 
            txtKupionaKsiazka.Location = new Point(747, 188);
            txtKupionaKsiazka.Margin = new Padding(3, 4, 3, 4);
            txtKupionaKsiazka.Name = "txtKupionaKsiazka";
            txtKupionaKsiazka.Size = new Size(114, 27);
            txtKupionaKsiazka.TabIndex = 0;
            // 
            // txtRokWydania
            // 
            txtRokWydania.Location = new Point(747, 257);
            txtRokWydania.Margin = new Padding(3, 4, 3, 4);
            txtRokWydania.Name = "txtRokWydania";
            txtRokWydania.Size = new Size(114, 27);
            txtRokWydania.TabIndex = 0;
            // 
            // txtPrzeczytaneStrony
            // 
            txtPrzeczytaneStrony.Location = new Point(747, 339);
            txtPrzeczytaneStrony.Margin = new Padding(3, 4, 3, 4);
            txtPrzeczytaneStrony.Name = "txtPrzeczytaneStrony";
            txtPrzeczytaneStrony.Size = new Size(114, 27);
            txtPrzeczytaneStrony.TabIndex = 0;
            // 
            // txtUlubionyAutor
            // 
            txtUlubionyAutor.Location = new Point(747, 63);
            txtUlubionyAutor.Margin = new Padding(3, 4, 3, 4);
            txtUlubionyAutor.Name = "txtUlubionyAutor";
            txtUlubionyAutor.Size = new Size(114, 27);
            txtUlubionyAutor.TabIndex = 0;
            // 
            // txtKoszyk
            // 
            txtKoszyk.Location = new Point(216, 335);
            txtKoszyk.Margin = new Padding(3, 4, 3, 4);
            txtKoszyk.Name = "txtKoszyk";
            txtKoszyk.Size = new Size(114, 27);
            txtKoszyk.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(111, 339);
            label5.Name = "label5";
            label5.Size = new Size(61, 20);
            label5.TabIndex = 5;
            label5.Text = "Koszyk :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(111, 257);
            label4.Name = "label4";
            label4.Size = new Size(54, 20);
            label4.TabIndex = 6;
            label4.Text = "Adres :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(96, 192);
            label3.Name = "label3";
            label3.Size = new Size(90, 20);
            label3.TabIndex = 7;
            label3.Text = "Podaj Wiek :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(81, 120);
            label2.Name = "label2";
            label2.Size = new Size(120, 20);
            label2.TabIndex = 8;
            label2.Text = "Podaj Nazwisko :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(99, 63);
            label1.Name = "label1";
            label1.Size = new Size(86, 20);
            label1.TabIndex = 9;
            label1.Text = "Podaj Imię :";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(592, 342);
            label10.Name = "label10";
            label10.Size = new Size(140, 20);
            label10.TabIndex = 10;
            label10.Text = "Przeczytane Strony :";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(626, 261);
            label9.Name = "label9";
            label9.Size = new Size(103, 20);
            label9.TabIndex = 11;
            label9.Text = "Rok Wydania :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(608, 192);
            label8.Name = "label8";
            label8.Size = new Size(124, 20);
            label8.TabIndex = 12;
            label8.Text = "Kupiona Książka :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(603, 125);
            label7.Name = "label7";
            label7.Size = new Size(129, 20);
            label7.TabIndex = 13;
            label7.Text = "Ulubiona Książka :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(613, 67);
            label6.Name = "label6";
            label6.Size = new Size(116, 20);
            label6.TabIndex = 14;
            label6.Text = "Ulubiony Autor :";
            // 
            // txtKsiazki
            // 
            txtKsiazki.Location = new Point(216, 517);
            txtKsiazki.Margin = new Padding(3, 4, 3, 4);
            txtKsiazki.Name = "txtKsiazki";
            txtKsiazki.Size = new Size(114, 27);
            txtKsiazki.TabIndex = 15;
            // 
            // txtPracownicy
            // 
            txtPracownicy.Location = new Point(216, 603);
            txtPracownicy.Margin = new Padding(3, 4, 3, 4);
            txtPracownicy.Name = "txtPracownicy";
            txtPracownicy.Size = new Size(114, 27);
            txtPracownicy.TabIndex = 15;
            // 
            // txtSklep
            // 
            txtSklep.Location = new Point(747, 511);
            txtSklep.Margin = new Padding(3, 4, 3, 4);
            txtSklep.Name = "txtSklep";
            txtSklep.Size = new Size(114, 27);
            txtSklep.TabIndex = 15;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(747, 611);
            txtEmail.Margin = new Padding(3, 4, 3, 4);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(114, 27);
            txtEmail.TabIndex = 15;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(58, 521);
            label11.Name = "label11";
            label11.Size = new Size(152, 20);
            label11.TabIndex = 16;
            label11.Text = "Książki w magazynie :";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(40, 606);
            label12.Name = "label12";
            label12.Size = new Size(170, 20);
            label12.TabIndex = 16;
            label12.Text = "Zatrudnieni Pracownicy :";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(623, 514);
            label13.Name = "label13";
            label13.Size = new Size(109, 20);
            label13.TabIndex = 16;
            label13.Text = "Nazwa Sklepu :";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(669, 617);
            label14.Name = "label14";
            label14.Size = new Size(59, 20);
            label14.TabIndex = 16;
            label14.Text = "E-mail :";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(6, 16);
            label15.Name = "label15";
            label15.Size = new Size(50, 20);
            label15.TabIndex = 0;
            label15.Text = "Oceny";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(94, 16);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 1;
            // 
            // dateCzas
            // 
            dateCzas.Format = DateTimePickerFormat.Custom;
            dateCzas.Location = new Point(336, 24);
            dateCzas.Name = "dateCzas";
            dateCzas.Size = new Size(278, 27);
            dateCzas.TabIndex = 21;
            dateCzas.Value = new DateTime(2023, 4, 19, 0, 0, 0, 0);
            // 
            // Sklep
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1523, 813);
            Controls.Add(dateCzas);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(txtEmail);
            Controls.Add(txtSklep);
            Controls.Add(txtPracownicy);
            Controls.Add(txtKsiazki);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonZatwierdz);
            Controls.Add(listBoxStore);
            Controls.Add(txtPrzeczytaneStrony);
            Controls.Add(txtKoszyk);
            Controls.Add(txtAdres);
            Controls.Add(txtRokWydania);
            Controls.Add(txtWiek);
            Controls.Add(txtKupionaKsiazka);
            Controls.Add(txtNazwisko);
            Controls.Add(txtUlubionyAutor);
            Controls.Add(txtUlubionaKsiazka);
            Controls.Add(txtImie);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Sklep";
            Text = "Sklep";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtImie;
        private TextBox txtNazwisko;
        private TextBox txtWiek;
        private TextBox txtAdres;
        private ListBox listBoxStore;
        private Button buttonZatwierdz;
        private TextBox txtUlubionaKsiazka;
        private TextBox txtKupionaKsiazka;
        private TextBox txtRokWydania;
        private TextBox txtPrzeczytaneStrony;
        private TextBox txtUlubionyAutor;
        private TextBox txtKoszyk;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox txtKsiazki;
        private TextBox txtPracownicy;
        private TextBox txtSklep;
        private TextBox txtEmail;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private TextBox textBox1;
        private DateTimePicker dateCzas;
    }
}